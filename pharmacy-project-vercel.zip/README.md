# Pharmacy Project

This is a starter Next.js project for your pharmacy app.