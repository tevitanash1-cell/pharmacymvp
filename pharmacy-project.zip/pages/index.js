import styles from '../styles/Home.module.css'

export default function Home() {
  return (
    <div className={styles.container}>
      <h1>Welcome to the Pharmacy Project</h1>
      <p>This is your Next.js starter app.</p>
    </div>
  )
}